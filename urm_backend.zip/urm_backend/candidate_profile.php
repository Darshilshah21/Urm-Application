<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');

// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

require './classes/database.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

// IF REQUEST METHOD IS NOT POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} else {
    // Check if the required parameters are provided
    if (!isset($data->tableName) || !isset($data->columns)) {
        $returnData = msg(0, 400, 'Invalid request. Missing table name or column data.');
    } else {
        $tableName = trim($data->tableName);
        $columns = $data->columns;

        // Check if the email exists in the database
        $email = trim($columns->email);
        $check_query = "SELECT * FROM `$tableName` WHERE email = :email";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bindValue(':email', $email, PDO::PARAM_STR);
        $check_stmt->execute();
        $row = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            // If email exists, update the user information
            $update_query = "UPDATE `$tableName` SET ";
            $updates = [];
            $values = [];

            foreach ($columns as $column => $value) {
                if ($column !== 'email') {
                    $updates[] = "$column = :$column";
                    $values[":$column"] = trim($value); // Store the sanitized value in the $values array
                }
            }

            $update_query .= implode(',', $updates) . " WHERE email = :email";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bindValue(':email', $email, PDO::PARAM_STR);

            try {
                $update_stmt->execute($values); // Pass the $values array here
                $returnData = msg(1, 200, 'Record updated successfully.');
            } catch (PDOException $e) {
                $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
            }
        } else {
            // If email does not exist, insert a new record
            // Create the INSERT query dynamically
            $insert_query = "INSERT INTO `$tableName` (";
            $placeholders = '';
            $columnNames = [];
            $values = [];

            foreach ($columns as $column => $value) {
                $columnNames[] = $column;
                $placeholders .= ':' . $column . ',';
                $values[":$column"] = trim($value); // Store the sanitized value in the $values array
            }

            $insert_query .= implode(',', $columnNames) . ') VALUES (' . rtrim($placeholders, ',') . ')';
            $insert_stmt = $conn->prepare($insert_query);

            try {
                $insert_stmt->execute($values); // Pass the $values array here
                $returnData = msg(1, 201, 'Record inserted successfully.');
            } catch (PDOException $e) {
                $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
            }
        }
    }
}

echo json_encode($returnData);
