<?php
header("Access-Control-Allow-Origin: *"); // Replace * with your frontend's actual domain if known
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

function fetchFacultyData($conn, $uid) {
    // Use a parameterized query to prevent SQL injection
    $query = "SELECT r.* FROM recruiter r, academia A, register u WHERE a.uid = ? AND a.aid = r.academiaId AND u.id = a.uid;";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $uid);
    $stmt->execute();

    $result = $stmt->get_result();

    $facultyData = array();
    while ($row = $result->fetch_assoc()) {
        $facultyData[] = $row;
    }

    $stmt->close();
    return $facultyData;
}

if (isset($_GET['uid'])) {
    $uid = $_GET['uid'];
    $facultyData = fetchFacultyData($conn, $uid);

    // Return the data as JSON
    header('Content-Type: application/json');
    echo json_encode($facultyData);
} else {
    // 'uid' parameter not provided in the request
    echo json_encode(array());
}
$conn->close();

?>
