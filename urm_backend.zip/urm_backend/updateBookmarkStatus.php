<?php
// Replace these variables with your actual database credentials
require './classes/database.php';

// Create a connection to the database
$db_connection = new Database();
$conn = $db_connection->dbConnection();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST"); // Change this to the appropriate HTTP method for updating data
header("Content-Type: application/json; charset=UTF-8");

// Get the data from the request body (assuming it's in JSON format)
$data = json_decode(file_get_contents("php://input"));

// Extract the details of the row to be updated
$ID = $data->ID;
$isBookmarked = $data->isBookmarked;

// Perform the update operation in the candidateDetails table
$update_query = "UPDATE `candidate_profile` SET `isBookmarked` = :isBookmarked WHERE `ID` = :ID";
$stmt = $conn->prepare($update_query);

try {
    $stmt->execute(array(
        'isBookmarked' => $isBookmarked,
        'ID' => $ID,
    ));

    $returnData = array(
        'success' => 1,
        'status' => 200,
        'message' => 'Bookmark status updated successfully.'
    );
    echo json_encode($returnData);
} catch (PDOException $e) {
    $returnData = array(
        'success' => 0,
        'status' => 500,
        'message' => 'Database error: ' . $e->getMessage()
    );
    echo json_encode($returnData);
}
// Close the database connection
$conn = null;
?>
