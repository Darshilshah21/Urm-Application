<?php

header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
// header('Access-Control-Allow-Headers: Content-Type');

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$user_id = $_GET['user_id'] ?? null;
// Handle form data
$sql = "SELECT * FROM academia WHERE uid = '$user_id'";
$result = mysqli_query($conn, $sql);

// Check if the record exists
if (mysqli_num_rows($result) > 0) {
    // Record exists, fetch the data
    $academiaData = mysqli_fetch_assoc($result);
    echo json_encode($academiaData); // Send the data as JSON response
} else {
    // Record does not exist, send a message
    $message = "Please update Academia information";
    echo json_encode(['message' => $message]); // Send the message as JSON response
}
    
$conn->close();

?>
