<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}



// function verifyPassword($password, $hashedPassword) {
//     return password_verify($password, $hashedPassword);
// }

// Handle form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $requestData = json_decode(file_get_contents('php://input'), true);

    if (isset($requestData['academia_Id']) && isset($requestData['Faculty_Name'])) {
        $academiaId = $requestData['academia_Id'];
        $facultyName = $requestData['Faculty_Name'];

    // Prepare and execute the SQL query to remove faculty data based on academiaId and Faculty_Name
    $query = "DELETE FROM academia_faculty WHERE AId = ? AND Faculty_Name = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $academiaId, $facultyName);
    
    if ($stmt->execute()) {
        echo "Faculty removed successfully";
    } else {
        echo "Error removing faculty: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Invalid request";
}



$conn->close();


}
?>
