<?php
header("Access-Control-Allow-Origin: *"); // Replace * with your frontend's actual domain if known
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

function fetchFacultyData($conn, $uid) {
    // Use a parameterized query to prevent SQL injection
    $query = "SELECT ja.job_id,cp.first_name,cp.last_name,cp.email, cp.field_of_study,cp.research_exp,cp.demographic,cp.interest, j.jobPosition FROM jobapplication ja, createjob j,candidate_profile cp, academia a where ja.candidate_id=cp.id and j.id=ja.job_id and j.academia_id=a.aid and a.uid=? and ja.status='Applied'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $uid);
    $stmt->execute();

    $result = $stmt->get_result();

    $facultyData = array();
    while ($row = $result->fetch_assoc()) {
        $facultyData[] = $row;
    }

    $stmt->close();
    return $facultyData;
}

if (isset($_GET['uid'])) {
    $uid = $_GET['uid'];
    $facultyData = fetchFacultyData($conn, $uid);

    // Return the data as JSON
    header('Content-Type: application/json');
    echo json_encode($facultyData);
} else {
    // 'uid' parameter not provided in the request
    echo json_encode(array());
}
$conn->close();

?>
