<?php

header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
// header('Access-Control-Allow-Headers: Content-Type');

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming your form fields are named 'aname', 'addr', and 'description'
    $user_id = $_POST['user_id'];
    $rTitle = $_POST['rtitle'];
    $rDescription = $_POST['rdesc'];

    $sql = "SELECT aid FROM academia WHERE uid = $user_id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $aid = $row['aid'];
  

    // Perform the SQL query to insert the data into your table
    $sql2 = "INSERT INTO academia_research VALUES ('$aid','$rTitle', '$rDescription')";

    $res = mysqli_query($conn, $sql2);

    if ($res) {
        // Send a success response back to the frontend
    //    echo "Success!";
        echo ("OK");
    } else {
        // Send an error response back to the frontend
        echo "KO";
    }
    
$conn->close();


}
?>
