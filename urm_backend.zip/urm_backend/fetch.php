<?php
// Replace these variables with your actual database credentials
require './classes/database.php';

// Create a connection to the database
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");

// Get the table name from the request URL
if (isset($_GET['tableName'])) {
    $tableName = $_GET['tableName'];

    // Perform the select operation
    $select_query = "SELECT * FROM `$tableName`";
    $stmt = $conn->prepare($select_query);

    try {
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($data);
     } catch (PDOException $e) {
        $errorInfo = $stmt->errorInfo();
        $returnData = msg(0, 500, 'Database error: ' . $e->getMessage() . ' SQLSTATE: ' . $errorInfo[0] . ' Error Code: ' . $errorInfo[1]);
        echo json_encode($returnData);
    }
} else {
    $returnData = msg(0, 400, 'Invalid request. Missing tableName.');
    echo json_encode($returnData);
}

// Close the database connection
$conn = null;

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}
?>
