<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');

// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}

function msg($success, $status, $data = []) {
    return [
        'success' => $success,
        'status' => $status,
        'data' => $data
    ];
}

require './classes/database.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// IF REQUEST METHOD IS NOT GET
if ($_SERVER["REQUEST_METHOD"] != "GET") {
    echo json_encode(msg(0, 404, 'Page Not Found!'));
    exit;
}

// Fetch data from the "createjob" table
$select_query = "SELECT * FROM apply_form";
$select_stmt = $conn->prepare($select_query);
$select_stmt->execute();
$result = $select_stmt->fetchAll(PDO::FETCH_ASSOC);

// Send the fetched data in the response
echo json_encode(msg(1, 200, $result));
?>