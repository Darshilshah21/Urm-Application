<?php
require './classes/database.php';

$db_connection = new Database();
$conn = $db_connection->dbConnection();

$data = json_decode(file_get_contents("php://input"));
$returnData = [];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

function updateData($tableName, $primaryKey, $data, $conn)
{
    if (isset($data->data->columns->$primaryKey)) {
        $primaryKeyValue = $data->data->columns->$primaryKey;

        $update_query = "UPDATE `$tableName` SET ";
        $update_columns = [];
        foreach ($data->data->columns as $column_name => $column_value) {
            if ($column_name !== $primaryKey) {
                $update_columns[] = "`$column_name` = :$column_name";
            }
        }
        $update_query .= implode(', ', $update_columns);
        $update_query .= " WHERE `$primaryKey` = :$primaryKey";

        $stmt = $conn->prepare($update_query);

        foreach ($data->data->columns as $column_name => $column_value) {
            if ($column_name !== $primaryKey) {
                $stmt->bindValue(":$column_name", $column_value);
            }
        }
        $stmt->bindValue(":$primaryKey", $primaryKeyValue);

        try {
            $stmt->execute();

            return msg(1, 200, 'Record updated successfully.');
        } catch (PDOException $e) {
            return msg(0, 500, 'Database error: ' . $e->getMessage());
        }
    } else {
        return msg(0, 400, 'Invalid request. Missing primary key value in columns data.');
    }
}

if (isset($data->tableName) && isset($data->primaryKey) && isset($data->data)) {
    $tableName = $data->tableName;
    $primaryKey = $data->primaryKey;
    $returnData = updateData($tableName, $primaryKey, $data, $conn);
} else {
    $returnData = msg(0, 400, 'Invalid request. Missing table name, primary key, or data.');
}

// ... existing code

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract the table name and columns from the data
    $data = json_decode(file_get_contents("php://input"), true);
    $tableName = $data["tableName"];
    $primaryKey = $data["primaryKey"];
    $columns = $data["data"]["columns"];

    // Construct the SQL query
    $sql = "UPDATE $tableName SET ";

    // Create a placeholder string for the column updates
    $columnUpdates = [];
    foreach ($columns as $columnName => $columnValue) {
        $columnUpdates[] = "$columnName = :$columnName";
    }
    $columnUpdatesStr = implode(", ", $columnUpdates);

    $sql .= $columnUpdatesStr;

    // Add WHERE clause using primary key
    $sql .= " WHERE $primaryKey = :$primaryKey";

    try {
        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        // Bind parameters for the column updates
        foreach ($columns as $columnName => $columnValue) {
            $stmt->bindValue(":$columnName", $columnValue);
        }

        // Bind the primary key parameter for the WHERE clause
        $stmt->bindValue(":$primaryKey", $columns[$primaryKey]);

        // Execute the update query
        $stmt->execute();

        // Send a success response back to the frontend
        $response = ["success" => 1, "message" => "Record updated successfully."];
        echo json_encode($response);
    } catch (PDOException $e) {
        // Send an error response back to the frontend
        $response = ["success" => 0, "message" => "Error: " . $e->getMessage()];
        echo json_encode($response);
    }

    // Close the database connection
    $conn = null;
} else {
    // Send an error response for invalid request method
    $response = ["success" => 0, "message" => "Invalid request method."];
    echo json_encode($response);
}


echo json_encode($returnData);

$conn = null;

function msg($success, $status, $message, $extra = [])
{
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}
?>
