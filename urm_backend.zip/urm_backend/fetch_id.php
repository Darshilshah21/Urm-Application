<?php
// Replace these variables with your actual database credentials
require './classes/database.php';

// Create a connection to the database
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET"); // Changed this to "GET" as we are performing a SELECT operation
header("Content-Type: application/json; charset=UTF-8");

// Get the table name and primary key from the request URL
if (isset($_GET['tableName']) && isset($_GET['primaryKey'])) {
    $tableName = $_GET['tableName'];
    $primaryKey = $_GET['primaryKey'];

    // Perform the select operation based on the primary key
    $select_query = "SELECT * FROM `$tableName` WHERE $primaryKey = :id";
    $stmt = $conn->prepare($select_query);

    try {
        // Bind the primary key value to the query
        $stmt->bindParam(':id', $primaryKey, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($data);
    } catch (PDOException $e) {
        $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
        echo json_encode($returnData);
    }
} else {
    $returnData = msg(0, 400, 'Invalid request. Missing tableName or primaryKey.');
    echo json_encode($returnData);
}

// Close the database connection
$conn = null;

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}
?>
