<?php
header("Access-Control-Allow-Origin: *"); // Replace * with your frontend's actual domain if known
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$user_id = $_GET['user_id'] ?? null;

function fetchFacultyData($conn,$user_id) {
    $query = "SELECT af.* FROM academia_faculty af, academia a where a.aid=af.aid and a.uid='$user_id'";
    $result = mysqli_query($conn, $query);

    $facultyData = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $facultyData[] = $row;
    }

    return $facultyData;
}


// Fetch all faculty records
$facultyData = fetchFacultyData($conn,$user_id); // Replace $your_db_connection with your actual database connection variable

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($facultyData); 
$conn->close();

?>
