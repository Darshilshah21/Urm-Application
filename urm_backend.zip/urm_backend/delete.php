<?php
require './classes/database.php';

// Create a connection to the database
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: DELETE");
header("Content-Type: application/json; charset=UTF-8");

// Get the identifier, table name, and primary key column name from the request URL
if (isset($_GET['identifier']) && isset($_GET['tableName']) && isset($_GET['primaryKey'])) {
    $identifier = $_GET['identifier'];
    $tableName = $_GET['tableName'];
    $primaryKeyColumn = $_GET['primaryKey'];

    // Perform the delete operation
    $delete_query = "DELETE FROM `$tableName` WHERE `$primaryKeyColumn` = :identifier";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bindValue(':identifier', $identifier, PDO::PARAM_INT);

    try {
        $delete_stmt->execute();
        $returnData = msg(1, 200, 'Record deleted successfully.');
    } catch (PDOException $e) {
        $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
    }

    echo json_encode($returnData);
} else {
    $returnData = msg(0, 400, 'Invalid request. Missing identifier, tableName, or primaryKey.');
    echo json_encode($returnData);
}

// Close the database connection
$conn = null;

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}
?>
