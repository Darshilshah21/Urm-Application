<?php

header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
// header('Access-Control-Allow-Headers: Content-Type');

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming your form fields are named 'aname', 'addr', and 'description'
    $job_Id = $_POST['job_id'];
    $status = $_POST['status'];

    // Perform the SQL query to insert the data into your table
    // $sql = "INSERT INTO academia  VALUES ('$academiaId','$academiaName', '$academiaAddress', '$academiaDescription', '$user_id')";
    // $sql_check = "SELECT COUNT(*) as count FROM academia WHERE uid = '$user_id'";
    // $result = mysqli_query($conn, $sql_check);

    $sql = "UPDATE jobapplication SET status = '$status' WHERE job_id = '$job_Id'";

$res = mysqli_query($conn, $sql);

if ($res) {
    // Send a success response back to the frontend
//    echo "Success!";
    echo ("OK");
} else {
    // Send an error response back to the frontend
    echo "KO";
}

    
$conn->close();


}
?>
