<?php
// Replace these variables with your actual database credentials
require './classes/database.php';

// Create a connection to the database
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET"); // Change this to the appropriate HTTP method for fetching data
header("Content-Type: application/json; charset=UTF-8");

if (isset($_GET['tableName'])) {
    $tableName = $_GET['tableName'];

    if ($tableName === 'createjob') {
        // Get job postings count based on DEI keywords
        $deiKeywords = array('diversity', 'equity', 'inclusion'); // Modify this array with your specific DEI keywords

        // Perform the select operation with DEI keywords filter
        $select_query = "SELECT COUNT(*) AS total FROM `$tableName` WHERE ";
        $conditions = array();
        foreach ($deiKeywords as $keyword) {
            $conditions[] = "`jobDescription` LIKE '%$keyword%'";
        }
        $select_query .= implode(' OR ', $conditions);
    } elseif ($tableName === 'candidate_profile') {
        // Get URM candidate count
        if (isset($_GET['where'])) {
            $where = $_GET['where'];
            $select_query = "SELECT COUNT(*) AS total FROM `$tableName` WHERE $where";
        } else {
            $returnData = msg(0, 400, 'Missing "where" parameter for candidateDetails table.');
            echo json_encode($returnData);
            exit;
        }
    } elseif ($tableName === 'deiEvents') {
        // Get DEI events count
        $select_query = "SELECT COUNT(*) AS total FROM `$tableName`";
    } else {
        $returnData = msg(0, 400, 'Invalid table name.');
        echo json_encode($returnData);
        exit;
    }

    $stmt = $conn->prepare($select_query);

    try {
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $totalCount = $row['total'];

        // Return the total count
        echo json_encode(['total' => $totalCount]);
    } catch (PDOException $e) {
        $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
        echo json_encode($returnData);
    }
} else {
    $returnData = msg(0, 400, 'Invalid request. Missing tableName.');
    echo json_encode($returnData);
}

// Close the database connection
$conn = null;

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}
?>
