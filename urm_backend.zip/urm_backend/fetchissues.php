
<?php

// Replace these variables with your actual database credentials
require './classes/database.php';

// Create a connection to the database
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET"); // Change this to the appropriate HTTP method for fetching data
header("Content-Type: application/json; charset=UTF-8");

// Get the table name from the request URL
if (isset($_GET['tableName'])) {
    $tableName = $_GET['tableName'];

    // Perform the select operation
    $select_query = "SELECT COUNT(*) AS total FROM `$tableName` WHERE status='pending'";
    $stmt = $conn->prepare($select_query);

    try {
       
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalIssues = $row['total'];
    } catch (PDOException $e) {
        $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
        echo json_encode($returnData);
    }
} else {
    $returnData = msg(0, 400, 'Invalid request. Missing tableName.');
    echo json_encode($returnData);
}

// Close the database connection
$conn = null;
echo json_encode(['totalIssues' => $totalIssues]);
function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}
?>
