<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');

// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

require './classes/database.php';
$db_connection = new Database();
$conn = $db_connection->dbConnection();

// Include PHPMailer classes
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// Create a new PHPMailer instance
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// GET DATA FROM REQUEST
$data = json_decode(file_get_contents("php://input"));
$returnData = [];
$username = $data->columns->username;
$email = $data->columns->email;
$password = $data->columns->password;
$role = $data->columns->role;

// IF REQUEST METHOD IS NOT POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} else {
    // Check if the required parameters are provided
    if (!isset($data->tableName) || !isset($data->columns)) {
        $returnData = msg(0, 400, 'Invalid request. Missing table name or column data.');
    } else {
        $tableName = trim($data->tableName);
        $columns = $data->columns;

        // Create the INSERT query dynamically
        $insert_query = "INSERT INTO `$tableName` (";
        $placeholders = '';
        $columnNames = [];

        foreach ($columns as $column => $value) {
            $columnNames[] = $column;
            $placeholders .= ':' . $column . ',';
        }

        $insert_query .= implode(',', $columnNames) . ') VALUES (' . rtrim($placeholders, ',') . ')';
        $insert_stmt = $conn->prepare($insert_query);

        // DATA BINDING
        foreach ($columns as $column => $value) {
            $insert_stmt->bindValue(':' . $column, trim($value), PDO::PARAM_STR);
        }

        try {
            $insert_stmt->execute();
            $returnData = msg(1, 201, 'Record inserted successfully.');
           
            $mail = new PHPMailer();

            // Set SMTP settings (replace these with your actual SMTP credentials)
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'urmapplication.group10@gmail.com';
            $mail->Password = 'kjnofzrgyvajnygs';
            $mail->SMTPSecure = 'tls'; // Use 'tls' or 'ssl' based on your server configuration
            $mail->Port = 587; // Use the appropriate SMTP port
            
            // Set the sender (your email address)
            $mail->setFrom('urmapplication.group10@gmail.com', 'URM Application');
            
            // Add the recipient's email address
            $mail->addAddress($email, 'Recipient Name');
            
            // Set the email subject and body
            $mail->Subject = 'URM Registration Email';
            $mail->Body = 'Your registration to the url Application was successfull';
            
            // Optionally, you can set the email body as HTML
            $mail->isHTML(true);
            $mail->Body = '<h1>Your registration to the url Application was successfull</h1>';
            
            // Send the email
            try {
                $mail->send();
                echo 'Email sent successfully.';
            } catch (Exception $e) {
                echo 'Failed to send email: ' . $mail->ErrorInfo;
            }
                            
        
        } catch (PDOException $e) {
            $returnData = msg(0, 500, 'Database error: ' . $e->getMessage());
            echo json_encode(['error' => 'Email could not be sent.']);
        }
    }
}

echo json_encode($returnData);

?>
