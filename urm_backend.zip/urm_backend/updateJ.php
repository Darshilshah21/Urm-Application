<?php
// updateJ.php

require './classes/database.php';

$db_connection = new Database();
$conn = $db_connection->dbConnection();

$data = json_decode(file_get_contents("php://input"), true);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract the data from the JSON payload
    $jobId = $data["jobId"];
    $status = $data["status"];

    // Construct the SQL query
    $sql = "UPDATE createjob SET status = :status WHERE jobId = :jobId";

    try {
        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        // Bind parameters for the update
        $stmt->bindValue(":status", $status);
        $stmt->bindValue(":jobId", $jobId);

        // Execute the update query
        $stmt->execute();

        // Send a success response back to the frontend
        $response = ["success" => 1, "message" => "Record updated successfully."];
        echo json_encode($response);
    } catch (PDOException $e) {
        // Send an error response back to the frontend
        $response = ["success" => 0, "message" => "Error: " . $e->getMessage()];
        echo json_encode($response);
    }

    // Close the database connection
    $conn = null;
} else {
    // Send an error response for invalid request method
    $response = ["success" => 0, "message" => "Invalid request method."];
    echo json_encode($response);
}
?>
