<?php

header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
// header('Access-Control-Allow-Headers: Content-Type');

// Set up your MySQL connection
$servername = '51.81.160.154';
$username = 'djs4331_urmwb';
$password = 'D@rshil2107';
$dbname = 'djs4331_urm';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming your form fields are named 'aname', 'addr', and 'description'
    $academiaId = $_POST['aid'];
    $academiaName = $_POST['name'];
    $academiaAddress = $_POST['addr'];
    $academiaDescription = $_POST['description'];
    $user_id = $_POST['user_id'];

    // Perform the SQL query to insert the data into your table
    // $sql = "INSERT INTO academia  VALUES ('$academiaId','$academiaName', '$academiaAddress', '$academiaDescription', '$user_id')";
    $sql_check = "SELECT COUNT(*) as count FROM academia WHERE uid = '$user_id'";
    $result = mysqli_query($conn, $sql_check);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $count = $row['count'];

    if ($count > 0) {
        // User_id already exists in the academia table, perform update
        $sql = "UPDATE academia 
                SET aid = '$academiaId', Name = '$academiaName', Address = '$academiaAddress', Description = '$academiaDescription' 
                WHERE uid = '$user_id'";
    } else {
        // User_id does not exist in the academia table, perform insert
        $sql = "INSERT INTO academia (aid, Name, Address, Description, uid)
                VALUES ('$academiaId', '$academiaName', '$academiaAddress', '$academiaDescription', '$user_id')";
    }


    $res = mysqli_query($conn, $sql);

    if ($res) {
        // Send a success response back to the frontend
    //    echo "Success!";
        echo ("OK");
    } else {
        // Send an error response back to the frontend
        echo "KO";
    }
}
    
$conn->close();


}
?>
