<?php

// Include PHPMailer classes
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// Create a new PHPMailer instance
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Create a new PHPMailer instance
$mail = new PHPMailer();

// Set SMTP settings (replace these with your actual SMTP credentials)
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'urmapplication.group10@gmail.com';
$mail->Password = 'kjnofzrgyvajnygs';
$mail->SMTPSecure = 'tls'; // Use 'tls' or 'ssl' based on your server configuration
$mail->Port = 587; // Use the appropriate SMTP port

// Set the sender (your email address)
$mail->setFrom('urmapplication.group10@gmail.com', 'URM Application');

// Add the recipient's email address
$mail->addAddress('manideepshanigaram.sm@gmail.com', 'Recipient Name');

// Set the email subject and body
$mail->Subject = 'Test Email';
$mail->Body = 'This is a test email sent using PHPMailer.';

// Optionally, you can set the email body as HTML
$mail->isHTML(true);
$mail->Body = '<h1>This is a test email sent using PHPMailer.</h1>';

// Send the email
try {
    $mail->send();
    echo 'Email sent successfully.';
} catch (Exception $e) {
    echo 'Failed to send email: ' . $mail->ErrorInfo;
}
?>
